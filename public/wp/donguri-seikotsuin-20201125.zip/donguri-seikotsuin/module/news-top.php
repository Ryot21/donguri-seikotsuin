
<!-- TOP > お知らせ -->

	<li>
		<a href="<?php the_permalink(); ?>">
			<p class="new-text">
				<span class="new-day"><?php the_time('Y.m.d'); ?></span><?php the_title(); ?>
			</p>
		</a>
	</li>
	