<div class="p-pagination">
  <?php
    if( function_exists('wp_pagenavi') ) {
      wp_pagenavi();
    }
  ?>
</div>
